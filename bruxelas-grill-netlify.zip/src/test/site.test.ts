import { describe, expect, it } from "vitest";
import { activeDelivery, delivery, openStatus } from "@/lib/site";

describe("faixas de delivery", () => {
  it("usa a frase pedida para o iFood", () => {
    expect(delivery.find((p) => p.id === "ifood")?.phrase).toBe("Deu fome? Estamos no iFood!");
  });

  it("usa a frase pedida para o 99 Food", () => {
    expect(delivery.find((p) => p.id === "99food")?.phrase).toBe("...Também estamos no 99 Food!");
  });

  it("esconde a faixa do 99 Food enquanto não houver link oficial", () => {
    const list = activeDelivery([
      { id: "ifood", label: "iFood", phrase: "a", url: "https://ifood.com.br/x" },
      { id: "99food", label: "99 Food", phrase: "b", url: "" },
    ]);
    expect(list.map((p) => p.id)).toEqual(["ifood"]);
  });
});

describe("horário de funcionamento", () => {
  it("sexta às 23h está aberto até meia-noite", () => {
    expect(openStatus(5, 23 * 60)).toEqual({ open: true, text: "Aberto agora · até meia-noite" });
  });

  it("segunda está fechado e abre na terça", () => {
    expect(openStatus(1, 20 * 60)).toEqual({ open: false, text: "Abrimos amanhã às 18h" });
  });

  it("terça às 23h já fechou", () => {
    expect(openStatus(2, 23 * 60).open).toBe(false);
  });
});
