import { createFileRoute } from "@tanstack/react-router";
import { About } from "@/components/site/About";
import { DeliveryStrip } from "@/components/site/DeliveryStrip";
import { Experience } from "@/components/site/Experience";
import { Gallery } from "@/components/site/Gallery";
import { Hero } from "@/components/site/Hero";
import { Instagram } from "@/components/site/Instagram";
import { Marquee } from "@/components/site/Marquee";
import { MenuTeaser } from "@/components/site/MenuTeaser";
import { Reviews } from "@/components/site/Reviews";
import { Signature } from "@/components/site/Signature";
import { Visit } from "@/components/site/Visit";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Bruxelas Grill | Gastrobar no Jardim Atlântico, Goiânia" },
      {
        name: "description",
        content:
          "Carnes na brasa, torresmo da roça, petiscos para dividir e drinks da casa. Gastrobar familiar no Jardim Atlântico, em Goiânia.",
      },
      { property: "og:title", content: "Bruxelas Grill | Gastrobar em Goiânia" },
      {
        property: "og:description",
        content: "Brasa acesa, cerveja gelada e mesa cheia. Conheça o cardápio e venha nos visitar.",
      },
      { property: "og:type", content: "restaurant" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <>
      <Hero />
      <Marquee />
      <About />
      <Signature />
      <MenuTeaser />
      <Experience />
      <Gallery />
      <Reviews />
      <Instagram />
      <Visit />
      <DeliveryStrip />
    </>
  );
}
