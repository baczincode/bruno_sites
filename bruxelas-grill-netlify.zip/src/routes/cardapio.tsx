import { useEffect, useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Search, ShoppingBag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DeliveryStrip } from "@/components/site/DeliveryStrip";
import { menu, type MenuItem } from "@/data/menu";
import { img } from "@/lib/images";
import { links } from "@/lib/site";
import { cn } from "@/lib/utils";

type MenuSearch = { categoria?: string | undefined };

const slug = (s: string) =>
  s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");

export const Route = createFileRoute("/cardapio")({
  validateSearch: (search: Record<string, unknown>): MenuSearch => ({
    categoria: typeof search["categoria"] === "string" ? search["categoria"] : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Cardápio | Bruxelas Grill Goiânia" },
      {
        name: "description",
        content:
          "Cardápio completo do Bruxelas Grill: espetinhos, petiscos, massas, mexidões, pratos individuais, drinks, cervejas e vinhos, com preços.",
      },
      { property: "og:title", content: "Cardápio do Bruxelas Grill" },
      {
        property: "og:description",
        content: "Do espetinho ao espumante: veja todos os pratos e bebidas com preços.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CardapioPage,
});

function CardapioPage() {
  const { categoria } = Route.useSearch();
  const [query, setQuery] = useState("");
  const [active, setActive] = useState(menu[0]?.name ?? "");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return menu;
    return menu
      .map((c) => ({ ...c, items: c.items.filter((i) => `${i.name} ${i.desc ?? ""}`.toLowerCase().includes(q)) }))
      .filter((c) => c.items.length > 0);
  }, [query]);

  useEffect(() => {
    if (!categoria) return;
    const el = document.getElementById(slug(categoria));
    if (el) {
      setActive(categoria);
      requestAnimationFrame(() => el.scrollIntoView({ behavior: "smooth", block: "start" }));
    }
  }, [categoria]);

  useEffect(() => {
    const obs = new IntersectionObserver(
      (entries) => {
        const vis = entries.filter((e) => e.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
        if (vis[0]) setActive(vis[0].target.getAttribute("data-cat") ?? "");
      },
      { rootMargin: "-170px 0px -60% 0px" },
    );
    document.querySelectorAll("[data-cat]").forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, [filtered]);

  useEffect(() => {
    document.getElementById(`chip-${slug(active)}`)?.scrollIntoView({ block: "nearest", inline: "center", behavior: "smooth" });
  }, [active]);

  const goTo = (name: string) => {
    document.getElementById(slug(name))?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <>
      <section className="relative isolate overflow-hidden pb-16 pt-36 md:pb-20 md:pt-44">
        <img src={img.cercadoRoca} alt="" aria-hidden="true" className="absolute inset-0 -z-20 h-full w-full object-cover" />
        <div className="absolute inset-0 -z-10 bg-coal/80" />
        <div className="grain -z-10" />
        <div className="container-site flex flex-wrap items-end justify-between gap-8">
          <div className="max-w-2xl">
            <p className="eyebrow">Cardápio</p>
            <h1 className="mt-5 text-[clamp(2.8rem,6vw,5rem)] font-semibold leading-[0.98]">
              O que sai da <em className="font-normal italic text-primary">nossa cozinha.</em>
            </h1>
            <p className="mt-5 max-w-lg text-lg text-foreground/75">
              Preços em reais, conforme o cardápio digital oficial. Para pedir, é só abrir o delivery.
            </p>
          </div>
          <Button asChild variant="hero" size="xl">
            <a href={links.order} target="_blank" rel="noopener noreferrer">
              <ShoppingBag /> Fazer pedido
            </a>
          </Button>
        </div>
      </section>

      <div className="sticky top-20 z-30 border-y border-paper-line bg-paper/95 backdrop-blur-xl">
        <div className="container-site flex items-center gap-4 py-3">
          <label className="relative hidden shrink-0 md:block">
            <span className="sr-only">Buscar no cardápio</span>
            <Search className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-paper-muted" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar prato ou bebida"
              className="h-11 w-64 rounded-full border border-paper-line bg-paper-deep pl-10 pr-4 text-sm text-paper-foreground outline-none placeholder:text-paper-muted focus:border-ember"
            />
          </label>
          <nav aria-label="Categorias" className="scrollbar-none flex gap-2 overflow-x-auto">
            {filtered.map((c) => (
              <button
                key={c.name}
                id={`chip-${slug(c.name)}`}
                type="button"
                onClick={() => goTo(c.name)}
                className={cn(
                  "h-10 shrink-0 rounded-full border px-4 text-sm font-medium transition-colors",
                  active === c.name
                    ? "border-paper-foreground bg-paper-foreground text-paper"
                    : "border-paper-line text-paper-foreground hover:border-paper-foreground",
                )}
              >
                {c.name}
              </button>
            ))}
          </nav>
        </div>
        <div className="container-site pb-3 md:hidden">
          <label className="relative block">
            <span className="sr-only">Buscar no cardápio</span>
            <Search className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-paper-muted" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar prato ou bebida"
              className="h-11 w-full rounded-full border border-paper-line bg-paper-deep pl-10 pr-4 text-sm text-paper-foreground outline-none placeholder:text-paper-muted focus:border-ember"
            />
          </label>
        </div>
      </div>

      <section className="section-paper min-h-[60vh] py-16 md:py-20">
        <div className="container-site">
          {filtered.length === 0 && (
            <div className="mx-auto max-w-md py-20 text-center">
              <p className="font-display text-2xl">Nada encontrado para “{query}”.</p>
              <p className="mt-3 text-paper-muted">Tente outro nome ou veja o cardápio digital completo.</p>
              <Button asChild variant="paper" size="pill" className="mt-6">
                <a href={links.menu} target="_blank" rel="noopener noreferrer">
                  Abrir cardápio digital
                </a>
              </Button>
            </div>
          )}

          <div className="space-y-20">
            {filtered.map((c) => (
              <div key={c.name} id={slug(c.name)} data-cat={c.name} className="scroll-mt-44">
                <div className="flex items-baseline gap-5">
                  <h2 className="text-3xl font-semibold md:text-4xl">{c.name}</h2>
                  <span className="h-px flex-1 bg-paper-line" />
                  <span className="text-sm text-paper-muted">{c.items.length} itens</span>
                </div>
                <div className="mt-8 grid gap-x-16 md:grid-cols-2">
                  {c.items.map((it) => (
                    <MenuRow key={it.name} item={it} />
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="mt-24 flex flex-col items-center gap-5 rounded-3xl bg-paper-deep px-6 py-14 text-center ring-1 ring-paper-line">
            <h2 className="text-3xl font-semibold md:text-4xl">Bateu a vontade?</h2>
            <p className="max-w-md text-paper-muted">Peça pelo cardápio digital oficial ou venha jantar com a gente.</p>
            <div className="flex flex-wrap justify-center gap-3">
              <Button asChild variant="paper" size="xl">
                <a href={links.order} target="_blank" rel="noopener noreferrer">
                  Fazer pedido
                </a>
              </Button>
              <Button asChild variant="paperOutline" size="xl">
                <a href={links.whatsapp} target="_blank" rel="noopener noreferrer">
                  Reservar mesa
                </a>
              </Button>
            </div>
          </div>
        </div>
      </section>
      <DeliveryStrip />
    </>
  );
}

function MenuRow({ item }: { item: MenuItem }) {
  return (
    <article className="flex items-start gap-4 border-b border-paper-line py-5">
      {item.img ? (
        <img
          src={item.img}
          alt={item.name}
          loading="lazy"
          className="size-16 shrink-0 rounded-full object-cover ring-2 ring-paper ring-offset-1 ring-offset-paper-line md:size-20"
        />
      ) : null}
      <div className="min-w-0 flex-1">
        <div className="flex items-baseline gap-3">
          <h3 className="font-display text-lg font-semibold leading-snug md:text-xl">{item.name}</h3>
          <span className="menu-dots" />
          <span className="shrink-0 font-semibold text-ember">R$ {item.price}</span>
        </div>
        {item.desc && <p className="mt-1.5 text-[0.95rem] leading-relaxed text-paper-muted">{item.desc}</p>}
      </div>
    </article>
  );
}
