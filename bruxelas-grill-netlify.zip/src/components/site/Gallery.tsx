import { useCallback, useEffect, useState } from "react";
import { ChevronLeft, ChevronRight, X } from "lucide-react";
import { img } from "@/lib/images";
import { cn } from "@/lib/utils";

const photos = [
  { src: img.cercadoRoca, cap: "Cercado da Roça", cls: "col-span-2 row-span-2" },
  { src: img.caipirinha, cap: "Caipirinha de limão", cls: "row-span-2" },
  { src: img.tilapiaEmpanada, cap: "Tilápia empanada no panko", cls: "" },
  { src: img.pastelzinho, cap: "Pastelzinho de carne com queijo", cls: "" },
  { src: img.frangoPassarinho, cap: "Frango à passarinho", cls: "col-span-2" },
  { src: img.jiloCaipira, cap: "Jiló caipira", cls: "" },
  { src: img.insta3, cap: "Clientes da casa", cls: "row-span-2" },
  { src: img.batataBoiBreado, cap: "Batata ao boi breado", cls: "" },
  { src: img.omeletePatrao, cap: "Omelete do Patrão", cls: "" },
  { src: img.filezinhoKids, cap: "Filezinho kids", cls: "" },
];

export function Gallery() {
  const [index, setIndex] = useState<number | null>(null);
  const close = useCallback(() => setIndex(null), []);
  const step = useCallback(
    (d: number) => setIndex((i) => (i === null ? i : (i + d + photos.length) % photos.length)),
    [],
  );

  useEffect(() => {
    if (index === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
      if (e.key === "ArrowLeft") step(-1);
      if (e.key === "ArrowRight") step(1);
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [index, close, step]);

  const current = index === null ? undefined : photos[index];

  return (
    <section id="galeria" className="section-paper py-24 md:py-32">
      <div className="container-site">
        <div className="reveal flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="eyebrow">Galeria</p>
            <h2 className="mt-5 text-[clamp(2.4rem,4.6vw,3.9rem)] font-semibold leading-[1.02]">
              A casa em <em className="font-normal italic text-ember">imagens.</em>
            </h2>
          </div>
          <p className="max-w-sm text-paper-muted">Fotos reais dos nossos pratos, drinks e de quem faz o Bruxelas acontecer.</p>
        </div>

        <div className="mt-14 grid grid-flow-dense auto-rows-[160px] grid-cols-2 gap-3 md:auto-rows-[210px] md:grid-cols-4 md:gap-4">
          {photos.map((p, i) => (
            <button
              key={p.cap}
              type="button"
              onClick={() => setIndex(i)}
              aria-label={`Ampliar: ${p.cap}`}
              className={cn(
                "reveal group relative cursor-zoom-in overflow-hidden rounded-2xl bg-paper-deep ring-1 ring-paper-line",
                p.cls,
              )}
            >
              <img
                src={p.src}
                alt={p.cap}
                loading="lazy"
                className="h-full w-full object-cover transition-transform duration-[1s] ease-out group-hover:scale-105"
              />
              <span className="bg-gradient-fade-up absolute inset-x-0 bottom-0 translate-y-full p-4 text-left text-sm font-medium text-foreground transition-transform duration-300 group-hover:translate-y-0">
                {p.cap}
              </span>
            </button>
          ))}
        </div>
      </div>

      {index !== null && current && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={current.cap}
          className="fixed inset-0 z-[80] flex animate-in fade-in items-center justify-center bg-coal/95 p-4 backdrop-blur-sm"
          onClick={(e) => e.target === e.currentTarget && close()}
        >
          <img src={current.src} alt={current.cap} className="max-h-[82vh] max-w-[min(94vw,1200px)] rounded-xl object-contain shadow-elegant" />
          <p className="absolute inset-x-0 bottom-6 text-center font-display text-lg italic text-foreground/80">
            {current.cap} · {index + 1}/{photos.length}
          </p>
          <LbButton className="right-4 top-4" label="Fechar" onClick={close}>
            <X />
          </LbButton>
          <LbButton className="left-3 top-1/2 -translate-y-1/2" label="Anterior" onClick={() => step(-1)}>
            <ChevronLeft />
          </LbButton>
          <LbButton className="right-3 top-1/2 -translate-y-1/2" label="Próxima" onClick={() => step(1)}>
            <ChevronRight />
          </LbButton>
        </div>
      )}
    </section>
  );
}

function LbButton({
  className,
  label,
  onClick,
  children,
}: {
  className: string;
  label: string;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      className={cn(
        "absolute grid size-12 place-items-center rounded-full bg-foreground/10 text-foreground transition-colors hover:bg-primary hover:text-primary-foreground [&_svg]:size-6",
        className,
      )}
    >
      {children}
    </button>
  );
}
