import { ArrowRight, UtensilsCrossed } from "lucide-react";
import { Food99Logo, IfoodLogo } from "@/components/site/icons";
import { activeDelivery, type DeliveryPlatform } from "@/lib/site";
import { cn } from "@/lib/utils";

const styles: Record<DeliveryPlatform["id"], { band: string; button: string; Logo: typeof IfoodLogo }> = {
  ifood: {
    band: "bg-ifood text-ifood-foreground",
    button: "border-ifood-foreground/70 text-ifood-foreground group-hover:bg-ifood-foreground group-hover:text-ifood",
    Logo: IfoodLogo,
  },
  "99food": {
    band: "bg-food99 text-food99-foreground",
    button: "border-food99-foreground/70 text-food99-foreground group-hover:bg-food99-foreground group-hover:text-food99",
    Logo: Food99Logo,
  },
};

const cardapioUrl =
  "https://www.vucafood.com.br/bruxelasgrill/2631/cardapio-digital?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAcGRvZgJzcnRjBmFwcF9pZA81NjcwNjczNDMzNTI0MjcAAadnX01JEB86EPS7gTIgjqHcAiFyVHGrp9_2YLvH6Nuc6DjApy5k3gH93Kr5-A_aem_8V30XkCNdf2IEQzNTkf9FA";

/** Faixas compactas de delivery no fim da página. Só aparecem plataformas com link oficial. */
export function DeliveryStrip() {
  const platforms = activeDelivery();
  return (
    <section aria-label="Delivery e cardápio">
      {platforms.map((p) => {
        const s = styles[p.id];
        return (
          <a
            key={p.id}
            href={p.url}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={`${p.phrase} Abrir ${p.label}`}
            className={cn("group block", s.band)}
          >
            <div className="container-site grid grid-cols-[auto_1fr_auto] items-center gap-4 py-5 md:gap-8 md:py-6">
              <s.Logo className="h-7 w-auto md:h-9" />
              <p className="text-center font-display text-lg font-semibold leading-tight md:text-2xl">{p.phrase}</p>
              <span
                className={cn(
                  "grid size-11 place-items-center rounded-full border transition-all duration-300 group-hover:translate-x-1 md:size-12",
                  s.button,
                )}
              >
                <ArrowRight className="size-5" />
              </span>
            </div>
          </a>
        );
      })}

      {/* Faixa de cardápio digital (estilo idêntico às faixas de delivery) */}
      <a
        href={cardapioUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Abrir o cardápio digital"
        className="group block bg-primary text-primary-foreground"
      >
        <div className="container-site grid grid-cols-[auto_1fr_auto] items-center gap-4 py-5 md:gap-8 md:py-6">
          <UtensilsCrossed className="size-7 md:size-9" strokeWidth={1.75} />
          <p className="text-center font-display text-lg font-semibold leading-tight md:text-2xl">
            Cardápio digital · peça agora
          </p>
          <span className="grid size-11 place-items-center rounded-full border border-primary-foreground/70 text-primary-foreground transition-all duration-300 group-hover:translate-x-1 group-hover:bg-primary-foreground group-hover:text-primary md:size-12">
            <ArrowRight className="size-5" />
          </span>
        </div>
      </a>
    </section>
  );
}
