import { Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { img } from "@/lib/images";

const dishes = [
  {
    name: "Cercado da Roça",
    tag: "Petisco da casa",
    price: "99,99",
    desc: "Costelinha suína assada e caramelizada no barbecue da casa, com mandioca frita e farofinha de bacon.",
    img: img.cercadoRoca,
    big: true,
  },
  {
    name: "Linguine com Camarões",
    tag: "Massa",
    price: "69,99",
    desc: "Linguine ao molho branco com camarões grelhados e ervilhas frescas.",
    img: img.linguineCamaroes,
  },
  {
    name: "Torresmo Caipira",
    tag: "Petisco",
    price: "44,99",
    desc: "Torresmo da roça super crocante, mandioca na manteiga de ervas e aioli de limão-cravo.",
    img: img.torresmoCaipira,
  },
  {
    name: "Mexidão Vila Rica",
    tag: "Para 2 ou 4",
    price: "109,99",
    desc: "Arroz cremoso com carne de sol, linguiça, queijo coalho, lombo, banana-da-terra e jiló, gratinado.",
    img: img.mexidaoVilaRica,
  },
  {
    name: "Ceviche de Tilápia",
    tag: "Entrada",
    price: "59,99",
    desc: "Tilápia marinada em cítricos, pimentas, cebola roxa, tomate cereja e manga. Com chips de mandioca.",
    img: img.cevicheTilapia,
  },
  {
    name: "Batata ao Boi Breado",
    tag: "Para a mesa",
    price: "75,99",
    desc: "Batatas rústicas atoladas em costela desfiada assada lentamente, com mix de queijo cremoso.",
    img: img.batataBoiBreado,
  },
];

export function Signature() {
  return (
    <section id="destaques" className="relative py-24 md:py-32">
      <div className="container-site">
        <div className="flex flex-wrap items-end justify-between gap-8">
          <div className="reveal max-w-2xl">
            <p className="eyebrow">Os queridinhos da casa</p>
            <h2 className="mt-5 text-[clamp(2.4rem,4.6vw,3.9rem)] font-semibold leading-[1.02]">
              Pratos que fazem a gente
              <em className="font-normal italic text-primary"> voltar.</em>
            </h2>
          </div>
          <Button asChild variant="glass" size="pill" className="reveal">
            <Link to="/cardapio">
              Cardápio completo <ArrowUpRight />
            </Link>
          </Button>
        </div>

        <div className="mt-14 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {dishes.map((d) => (
            <article
              key={d.name}
              className={
                "reveal group relative isolate flex min-h-[380px] flex-col justify-end overflow-hidden rounded-2xl shadow-elegant " +
                (d.big ? "md:col-span-2 lg:row-span-2 lg:min-h-[640px]" : "")
              }
            >
              <img
                src={d.img}
                alt={d.name}
                loading="lazy"
                className="absolute inset-0 -z-20 h-full w-full object-cover transition-transform duration-[1.2s] ease-out group-hover:scale-105"
              />
              <div className="bg-gradient-fade-up absolute inset-0 -z-10" />
              <div className="p-6 md:p-8">
                <span className="inline-block rounded-full border border-foreground/25 bg-coal/40 px-3 py-1 text-[0.7rem] font-semibold uppercase tracking-[0.18em] text-foreground/90 backdrop-blur">
                  {d.tag}
                </span>
                <div className="mt-4 flex items-end justify-between gap-4">
                  <h3 className={d.big ? "text-4xl font-semibold md:text-5xl" : "text-2xl font-semibold"}>{d.name}</h3>
                  <p className="shrink-0 font-display text-xl text-primary-glow">
                    <span className="text-sm text-foreground/60">R$ </span>
                    {d.price}
                  </p>
                </div>
                <p className={"mt-3 text-foreground/75 " + (d.big ? "max-w-md text-lg" : "text-[0.95rem]")}>{d.desc}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
