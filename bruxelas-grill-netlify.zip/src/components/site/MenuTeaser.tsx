import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { menu } from "@/data/menu";
import { img } from "@/lib/images";
import { links } from "@/lib/site";

const tiles = [
  { cat: "Espetinhos", label: "Espetinhos", img: img.espetinhoFrangoBacon },
  { cat: "Petiscos", label: "Petiscos", img: img.torresmoLaminado },
  { cat: "Entradas", label: "Entradas", img: img.saladinhaRoca },
  { cat: "Pratos individuais", label: "Individuais", img: img.omeletePatrao },
  { cat: "Petiscos da casa", label: "Da casa", img: img.figadoJilo },
  { cat: "Drinks com álcool", label: "Drinks", img: img.caipirinha },
];

function count(cat: string) {
  return menu.find((c) => c.name === cat)?.items.length ?? 0;
}

export function MenuTeaser() {
  return (
    <section className="section-paper bg-paper-deep py-24 md:py-28">
      <div className="container-site grid gap-14 lg:grid-cols-[0.9fr_1.4fr] lg:items-center">
        <div className="reveal">
          <p className="eyebrow">Cardápio</p>
          <h2 className="mt-5 text-[clamp(2.2rem,4vw,3.4rem)] font-semibold leading-[1.05]">
            Do espetinho ao espumante.
          </h2>
          <p className="mt-6 max-w-md text-lg leading-relaxed text-paper-muted">
            {menu.length} categorias com entradas, petiscos, massas, mexidões, pratos individuais, menu kids, drinks,
            cervejas, doses e carta de vinhos.
          </p>
          <div className="mt-9 flex flex-wrap gap-3">
            <Button asChild variant="paper" size="xl">
              <Link to="/cardapio">
                Abrir o cardápio <ArrowRight />
              </Link>
            </Button>
            <Button asChild variant="paperOutline" size="xl">
              <a href={links.order} target="_blank" rel="noopener noreferrer">
                Pedir delivery
              </a>
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
          {tiles.map((t) => (
            <Link
              key={t.cat}
              to="/cardapio"
              search={{ categoria: t.cat }}
              className="reveal group relative block aspect-[4/5] overflow-hidden rounded-2xl shadow-paper"
            >
              <img
                src={t.img}
                alt={t.label}
                loading="lazy"
                className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="bg-gradient-fade-up absolute inset-0" />
              <div className="absolute inset-x-0 bottom-0 flex items-end justify-between p-4 text-foreground">
                <div>
                  <p className="font-display text-xl font-semibold">{t.label}</p>
                  <p className="text-xs text-foreground/70">{count(t.cat)} opções</p>
                </div>
                <span className="grid size-8 place-items-center rounded-full bg-primary text-primary-foreground transition-transform duration-300 group-hover:translate-x-0.5">
                  <ArrowRight className="size-4" />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
