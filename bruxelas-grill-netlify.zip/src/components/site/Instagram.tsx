import { ArrowUpRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { InstagramIcon } from "@/components/site/icons";
import { img } from "@/lib/images";
import { links, site } from "@/lib/site";

const posts = [
  { src: img.insta1, url: "https://www.instagram.com/bruxelasgrill/p/Df122W4hzHf/", alt: "Fachada do Bruxelas Grill" },
  { src: img.insta4, url: "https://www.instagram.com/bruxelasgrill/p/Dfs0HLAtAgz/", alt: "Linguine com camarões" },
  { src: img.insta2, url: "https://www.instagram.com/bruxelasgrill/p/Df2nkaJMTwG/", alt: "Amigos reunidos à noite" },
  { src: img.insta5, url: "https://www.instagram.com/bruxelasgrill/p/DfnVCGLhfg3/", alt: "Ceviche de tilápia" },
  { src: img.insta7, url: "https://www.instagram.com/bruxelasgrill/p/DdKNJXPpXeb/", alt: "Picanha com arroz e fritas" },
  { src: img.insta6, url: "https://www.instagram.com/bruxelasgrill/p/DfnUMCBhVAl/", alt: "Costelinha ao barbecue" },
];

export function Instagram() {
  return (
    <section className="relative overflow-hidden bg-coal py-24 md:py-32">
      <div className="container-site">
        <div className="reveal flex flex-col items-center text-center">
          <span className="grid size-14 place-items-center rounded-2xl bg-gradient-ember text-primary-foreground shadow-ember">
            <InstagramIcon className="size-7" />
          </span>
          <p className="eyebrow mt-6">Instagram</p>
          <h2 className="mt-4 text-[clamp(2.2rem,4vw,3.4rem)] font-semibold">
            Acompanhe o <em className="font-normal italic text-primary">Bruxelas</em>
          </h2>
          <a
            href={links.instagram}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-3 font-medium text-muted-foreground transition-colors hover:text-primary"
          >
            {site.instagramHandle}
          </a>
        </div>

        <div className="mt-14 grid grid-cols-2 gap-3 md:grid-cols-3 md:gap-4 lg:grid-cols-6">
          {posts.map((p, i) => (
            <a
              key={p.url}
              href={p.url}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={`Ver no Instagram: ${p.alt}`}
              className={"reveal group relative block aspect-[3/4] overflow-hidden rounded-xl ring-1 ring-border " + (i % 2 ? "lg:translate-y-8" : "")}
            >
              <img src={p.src} alt={p.alt} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
              <span className="absolute inset-0 grid place-items-center bg-coal/60 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                <ArrowUpRight className="size-8 text-foreground" />
              </span>
            </a>
          ))}
        </div>

        <div className="mt-20 flex justify-center">
          <Button asChild variant="hero" size="xl">
            <a href={links.instagram} target="_blank" rel="noopener noreferrer">
              <InstagramIcon /> Seguir {site.instagramHandle}
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
}
