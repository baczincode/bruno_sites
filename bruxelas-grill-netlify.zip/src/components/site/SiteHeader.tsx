import { useEffect, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import logoFull from "@/assets/logo-full.svg";
import { Button } from "@/components/ui/button";
import { links } from "@/lib/site";
import { cn } from "@/lib/utils";

const nav = [
  { label: "O Bruxelas", to: "/", hash: "sobre" },
  { label: "Destaques", to: "/", hash: "destaques" },
  { label: "Cardápio", to: "/cardapio" },
  { label: "Galeria", to: "/", hash: "galeria" },
  { label: "Visite", to: "/", hash: "visite" },
] as const;

export function SiteHeader() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const solid = scrolled || pathname !== "/" || open;

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setOpen(false), [pathname]);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        solid ? "border-b border-border/60 bg-coal/90 backdrop-blur-xl" : "bg-transparent",
      )}
    >
      <div className="container-site flex h-20 items-center justify-between gap-6">
        <Link to="/" aria-label="Bruxelas Grill, início" className="shrink-0">
          <img src={logoFull} alt="Bruxelas Grill" className="h-11 w-auto md:h-12" />
        </Link>

        <nav className="hidden items-center gap-8 lg:flex" aria-label="Principal">
          {nav.map((item) => (
            <Link
              key={item.label}
              to={item.to}
              {...("hash" in item ? { hash: item.hash } : {})}
              className="group relative py-2 text-sm font-medium text-foreground/85 transition-colors hover:text-foreground"
            >
              {item.label}
              <span className="absolute inset-x-0 bottom-0 h-px origin-left scale-x-0 bg-primary transition-transform duration-300 group-hover:scale-x-100" />
            </Link>
          ))}
        </nav>

        <div className="hidden lg:block">
          <Button asChild variant="hero" size="pill">
            <a href={links.order} target="_blank" rel="noopener noreferrer">
              Fazer pedido
            </a>
          </Button>
        </div>

        <button
          type="button"
          className="grid size-11 place-items-center rounded-full border border-foreground/20 text-foreground lg:hidden"
          aria-label={open ? "Fechar menu" : "Abrir menu"}
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>
      </div>

      <div
        className={cn(
          "overflow-hidden transition-[max-height] duration-500 lg:hidden",
          open ? "max-h-[520px]" : "max-h-0",
        )}
      >
        <nav className="container-site flex flex-col pb-8" aria-label="Menu móvel">
          {nav.map((item) => (
            <Link
              key={item.label}
              to={item.to}
              {...("hash" in item ? { hash: item.hash } : {})}
              onClick={() => setOpen(false)}
              className="border-b border-border/60 py-4 font-display text-2xl text-foreground"
            >
              {item.label}
            </Link>
          ))}
          <Button asChild variant="hero" size="xl" className="mt-6">
            <a href={links.order} target="_blank" rel="noopener noreferrer">
              Fazer pedido
            </a>
          </Button>
        </nav>
      </div>
    </header>
  );
}
