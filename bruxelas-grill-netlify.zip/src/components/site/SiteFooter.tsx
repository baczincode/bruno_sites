import { Link } from "@tanstack/react-router";
import logoFull from "@/assets/logo-full.svg";
import { InstagramIcon, WhatsAppIcon } from "@/components/site/icons";
import { hours, links, site } from "@/lib/site";

export function SiteFooter() {
  const open = hours.filter((h) => h.open !== null);
  return (
    <footer className="relative overflow-hidden bg-coal pt-20">
      <div className="container-site grid gap-12 md:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
        <div>
          <img src={logoFull} alt="Bruxelas Grill" className="h-20 w-auto" />
          <p className="mt-6 max-w-xs leading-relaxed text-muted-foreground">
            Gastrobar no Jardim Atlântico, em Goiânia. Brasa, petiscos, drinks e o Manneken Pis na porta.
          </p>
          <div className="mt-6 flex gap-3">
            <a
              href={links.instagram}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Instagram"
              className="grid size-11 place-items-center rounded-full border border-border text-foreground transition-colors hover:border-primary hover:text-primary"
            >
              <InstagramIcon className="size-5" />
            </a>
            <a
              href={links.whatsapp}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="WhatsApp"
              className="grid size-11 place-items-center rounded-full border border-border text-foreground transition-colors hover:border-primary hover:text-primary"
            >
              <WhatsAppIcon className="size-5" />
            </a>
          </div>
        </div>

        <FooterCol title="Endereço">
          <a href={links.maps} target="_blank" rel="noopener noreferrer" className="hover:text-foreground">
            {site.address}
            <br />
            {site.neighborhood}, {site.city}
            <br />
            CEP {site.cep}
          </a>
          <a href={links.tel} className="mt-3 block hover:text-foreground">
            {site.phone}
          </a>
        </FooterCol>

        <FooterCol title="Horários">
          {open.map((h) => (
            <p key={h.day}>
              {h.day}: <span className="text-foreground/85">{h.label}</span>
            </p>
          ))}
          <p className="mt-1">Domingo e segunda: fechado</p>
        </FooterCol>

        <FooterCol title="Navegue">
          <Link to="/" hash="sobre" className="block hover:text-foreground">
            O Bruxelas
          </Link>
          <Link to="/cardapio" className="block hover:text-foreground">
            Cardápio
          </Link>
          <a href={links.order} target="_blank" rel="noopener noreferrer" className="block hover:text-foreground">
            Delivery
          </a>
          <Link to="/" hash="visite" className="block hover:text-foreground">
            Como chegar
          </Link>
        </FooterCol>
      </div>

      <p
        aria-hidden="true"
        className="text-outline pointer-events-none mt-16 select-none whitespace-nowrap text-center font-display text-[18vw] font-semibold leading-[0.8]"
      >
        Bruxelas
      </p>

      <div className="border-t border-border/70">
        <div className="container-site flex flex-wrap justify-between gap-3 py-6 pr-20 text-sm text-muted-foreground">
          <span>© {new Date().getFullYear()} Bruxelas Grill. Todos os direitos reservados.</span>
          <span>Beba com moderação.</span>
        </div>
      </div>
    </footer>
  );
}

function FooterCol({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h4 className="font-sans text-xs font-semibold uppercase tracking-[0.22em] text-primary">{title}</h4>
      <div className="mt-5 space-y-1.5 text-[0.95rem] leading-relaxed text-muted-foreground">{children}</div>
    </div>
  );
}
