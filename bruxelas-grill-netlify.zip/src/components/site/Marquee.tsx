const words = [
  "Picanha na grelha",
  "Torresmo da roça",
  "Cerveja trincando",
  "Drinks da casa",
  "Mexidão Vila Rica",
  "Espetinhos na brasa",
  "Ceviche de tilápia",
  "Carta de vinhos",
];

export function Marquee() {
  const row = [...words, ...words];
  return (
    <div className="bg-gradient-ember relative overflow-hidden py-4 text-primary-foreground" aria-hidden="true">
      <div className="flex w-max animate-marquee items-center gap-10 whitespace-nowrap">
        {row.map((w, i) => (
          <span key={i} className="flex items-center gap-10 font-display text-xl italic md:text-2xl">
            {w}
            <span className="text-base not-italic opacity-60">✦</span>
          </span>
        ))}
      </div>
    </div>
  );
}
