import { useEffect, useState } from "react";
import { MapPin, Navigation, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { WhatsAppIcon } from "@/components/site/icons";
import { hours, links, site } from "@/lib/site";
import { cn } from "@/lib/utils";

// Segunda primeiro na tabela.
const order = [1, 2, 3, 4, 5, 6, 0];

export function Visit() {
  const [today, setToday] = useState<number | null>(null);
  useEffect(() => setToday(new Date().getDay()), []);

  return (
    <section id="visite" className="relative py-24 md:py-32">
      <div className="container-site">
        <div className="reveal max-w-2xl">
          <p className="eyebrow">Visite</p>
          <h2 className="mt-5 text-[clamp(2.4rem,4.6vw,3.9rem)] font-semibold leading-[1.02]">
            Venha nos <em className="font-normal italic text-primary">visitar.</em>
          </h2>
        </div>

        <div className="mt-14 grid gap-8 lg:grid-cols-[1.25fr_1fr]">
          <div className="reveal relative min-h-[420px] overflow-hidden rounded-2xl ring-1 ring-border">
            <iframe
              title="Mapa do Bruxelas Grill"
              src={links.mapsEmbed}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              className="absolute inset-0 h-full w-full grayscale-[0.6] invert-[0.9] hue-rotate-180 contrast-[0.9]"
            />
            <a
              href={links.maps}
              target="_blank"
              rel="noopener noreferrer"
              className="absolute bottom-4 left-4 right-4 flex items-center gap-4 rounded-xl bg-coal/90 p-4 backdrop-blur-md transition-colors hover:bg-coal md:right-auto"
            >
              <span className="grid size-11 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground">
                <MapPin className="size-5" />
              </span>
              <span>
                <span className="block font-semibold">{site.address}</span>
                <span className="block text-sm text-muted-foreground">
                  {site.neighborhood}, {site.city} · CEP {site.cep}
                </span>
              </span>
            </a>
          </div>

          <div className="reveal flex flex-col rounded-2xl bg-card p-7 ring-1 ring-border md:p-9">
            <h3 className="text-2xl font-semibold">Horários</h3>
            <table className="mt-5 w-full text-[0.95rem]">
              <tbody>
                {order.map((d) => {
                  const h = hours[d]!;
                  const isToday = today === d;
                  return (
                    <tr key={h.day} className={cn("border-b border-border/70 last:border-0", isToday && "text-primary")}>
                      <td className="py-3">
                        {h.day}
                        {isToday && (
                          <span className="ml-2 rounded-full bg-primary/15 px-2 py-0.5 text-[0.65rem] font-semibold uppercase tracking-wider">
                            hoje
                          </span>
                        )}
                      </td>
                      <td className={cn("py-3 text-right tabular-nums", h.open === null && !isToday && "text-muted-foreground")}>
                        {h.label}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild variant="hero" size="pill">
                <a href={links.maps} target="_blank" rel="noopener noreferrer">
                  <Navigation /> Como chegar
                </a>
              </Button>
              <Button asChild variant="glass" size="pill">
                <a href={links.whatsapp} target="_blank" rel="noopener noreferrer">
                  <WhatsAppIcon /> Reservar
                </a>
              </Button>
              <Button asChild variant="glass" size="pill">
                <a href={links.tel}>
                  <Phone /> {site.phone}
                </a>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
