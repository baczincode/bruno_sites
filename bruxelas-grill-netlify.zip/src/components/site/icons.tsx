import type { SVGProps } from "react";

// Símbolo oficial do iFood (wordmark), em cor herdada.
export function IfoodLogo(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 1004 530.58" fill="currentColor" role="img" aria-label="iFood" {...props}>
      <path
        transform="translate(4 -224.71)"
        d="M-4,529.31H72.41l42.46-211.2H38.45ZM42.66,292.92h76.73L132,229.73H55.3Zm59.47,295.82h76.42l46.69-228.18h57.31L291,318.11H234.79l2.130-9.55c3.18-18,9.55-38.21,38.2-38.21,17,0,32.91,1.060,48.82,8.49l8.5-44.570a167.8,167.8,0,0,0-55.19-9.56c-61.56,0-104,36.090-119.930,93.4H130.79l-8.49,42.45h26.53Z"
      />
      <path
        transform="translate(4 -224.71)"
        d="M344.11,533.56c90.21,0,152.83-81.73,152.83-148.59,0-49.88-45.64-71.11-90.21-71.11C308,313.86,253.9,402,253.9,462.45c0,49.88,46.7,71.11,90.21,71.11m242,0c90.21,0,152.83-81.73,152.83-148.59,0-49.88-46.7-71.11-91.28-71.11-98.7,0-152.82,88.09-152.82,148.59,0,49.88,47.76,71.11,91.27,71.11m277-4.25h75.35L1000,229H923.59l-18.05,89.15-31.84-3.18c-74.29,0-142.21,95.51-142.21,163.44,0,27.59,18,55.19,48.82,55.19,43.51,0,74.29-21.23,87-42.46h4.24ZM627.48,687.45a295,295,0,0,1-212.26,66.86c-100.83-6.37-173-83.85-185.73-165.57h4.240c23.35,51,79.6,98.71,148.59,106.13,70,8.49,153.89-23.34,199.52-66.86L530.9,588.74H684.79l-34,163.45-22.29-63.68Z"
      />
    </svg>
  );
}

// Marca tipográfica do 99 Food (usada só quando houver link oficial).
export function Food99Logo(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 220 80" role="img" aria-label="99 Food" {...props}>
      <text
        x="0"
        y="62"
        fill="currentColor"
        fontFamily="Instrument Sans, system-ui, sans-serif"
        fontWeight="800"
        fontSize="68"
        letterSpacing="-3"
      >
        99Food
      </text>
    </svg>
  );
}

export function WhatsAppIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 32 32" fill="currentColor" aria-hidden="true" {...props}>
      <path d="M16.04 3C9.4 3 4 8.4 4 15.04c0 2.12.55 4.18 1.6 6L4 28l7.12-1.87a12 12 0 0 0 4.92 1.04C22.68 27.17 28 21.78 28 15.04S22.68 3 16.04 3Zm0 21.9c-1.55 0-3.07-.42-4.4-1.2l-.32-.19-3.3.87.88-3.22-.2-.33a9.7 9.7 0 0 1-1.5-5.2c0-5.4 4.4-9.8 9.84-9.8 5.4 0 9.8 4.4 9.8 9.8s-4.4 9.27-9.8 9.27Zm5.4-7.34c-.3-.15-1.75-.86-2.02-.96-.27-.1-.47-.15-.67.15-.2.3-.77.96-.94 1.16-.17.2-.35.22-.65.07-.3-.15-1.25-.46-2.38-1.47-.88-.78-1.470-1.75-1.64-2.05-.17-.3-.02-.46.13-.6.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.07-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.5h-.57c-.2 0-.52.07-.8.37-.27.3-1.04 1.02-1.04 2.48s1.07 2.88 1.22 3.08c.15.2 2.1 3.2 5.080 4.5.7.3 1.26.48 1.7.62.72.23 1.37.2 1.88.12.57-.08 1.75-.72 2-1.4.25-.7.25-1.3.17-1.42-.07-.12-.27-.2-.57-.35Z" />
    </svg>
  );
}

export function InstagramIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true" {...props}>
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
    </svg>
  );
}
