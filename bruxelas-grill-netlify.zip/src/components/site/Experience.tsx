import { Baby, GlassWater, Music2 } from "lucide-react";
import { img } from "@/lib/images";

const points = [
  { icon: GlassWater, title: "Cerveja & drinks", text: "Cerveja trincando, gin tônicas, mojitos, caipirinhas e soda italiana para quem não bebe." },
  { icon: Music2, title: "Noites animadas", text: "Sexta e sábado até meia-noite, com a casa cheia e programação especial no Instagram." },
  { icon: Baby, title: "Família à mesa", text: "Menu “Para os amados filhotes” e um ambiente acolhedor para todas as idades." },
];

const drinks = [
  { name: "Aperol Spritz", price: "24,99", img: img.aperol },
  { name: "Caipirinha de limão", price: "24,99", img: img.caipirinha },
  { name: "Piña Colada", price: "24,99", img: img.pinaColada },
  { name: "Soda italiana", price: "19,99", img: img.sodaMorango },
];

export function Experience() {
  return (
    <section className="relative isolate overflow-hidden">
      <div className="relative min-h-[640px] py-28 md:py-36">
        <img
          src={img.noiteBar}
          alt="Mesa com chopp, drinks e petiscos em uma noite animada"
          loading="lazy"
          className="absolute inset-0 -z-20 h-full w-full object-cover"
        />
        <div className="absolute inset-0 -z-10 bg-coal/75" />
        <div className="grain -z-10" />

        <div className="container-site">
          <div className="reveal max-w-3xl">
            <p className="eyebrow">A experiência</p>
            <h2 className="mt-5 text-[clamp(2.4rem,5vw,4.4rem)] font-semibold leading-[1.02]">
              Uma experiência que vai
              <em className="font-normal italic text-primary"> muito além do sabor.</em>
            </h2>
          </div>

          <div className="mt-16 grid gap-10 md:grid-cols-3">
            {points.map(({ icon: Icon, title, text }) => (
              <div key={title} className="reveal border-t border-primary/70 pt-6">
                <Icon className="size-7 text-primary" strokeWidth={1.5} />
                <h3 className="mt-4 text-2xl font-semibold">{title}</h3>
                <p className="mt-2 leading-relaxed text-foreground/75">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-coal py-20">
        <div className="container-site">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <h3 className="reveal text-3xl font-semibold md:text-4xl">
              Do nosso <em className="font-normal italic text-primary">bar</em>
            </h3>
            <p className="reveal text-sm text-muted-foreground">18 drinks com álcool · 4 sem álcool · cervejas, doses e vinhos</p>
          </div>
          <div className="scrollbar-none -mx-5 mt-10 flex snap-x gap-5 overflow-x-auto px-5 md:mx-0 md:grid md:grid-cols-4 md:overflow-visible md:px-0">
            {drinks.map((d) => (
              <figure key={d.name} className="reveal group w-[64vw] shrink-0 snap-start md:w-auto">
                <div className="arch aspect-[3/4] overflow-hidden bg-card ring-1 ring-border">
                  <img
                    src={d.img}
                    alt={d.name}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                </div>
                <figcaption className="mt-4 flex items-baseline justify-between gap-3">
                  <span className="font-display text-lg">{d.name}</span>
                  <span className="text-sm font-semibold text-primary-glow">R$ {d.price}</span>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
