import { Beer, Flame, HeartHandshake, UtensilsCrossed } from "lucide-react";
import logoShield from "@/assets/logo-shield.svg";
import { img } from "@/lib/images";
import { menu } from "@/data/menu";

const itemCount = menu.reduce((n, c) => n + c.items.length, 0);

const pillars = [
  {
    icon: Flame,
    title: "Carnes na brasa",
    text: "Picanha, cupim, contra-filé e espetinhos que saem direto da grelha.",
  },
  {
    icon: UtensilsCrossed,
    title: "Para dividir",
    text: "Torresmo, ceviche, fígado com jiló e petiscos pensados para a mesa toda.",
  },
  {
    icon: Beer,
    title: "Bar completo",
    text: "Cervejas geladas, gin tônicas, caipirinhas, carta de vinhos e espumantes.",
  },
  {
    icon: HeartHandshake,
    title: "Clima de família",
    text: "Menu kids, atendimento caloroso e espaço para comemorar sem pressa.",
  },
];

export function About() {
  return (
    <section id="sobre" className="section-paper relative overflow-hidden py-24 md:py-32">
      <img
        src={logoShield}
        alt=""
        aria-hidden="true"
        className="pointer-events-none absolute -right-24 top-10 h-[620px] w-auto opacity-[0.06]"
      />
      <div className="container-site grid items-center gap-16 lg:grid-cols-[1.05fr_1fr] lg:gap-20">
        <div className="reveal">
          <p className="eyebrow">O Bruxelas</p>
          <h2 className="mt-5 text-[clamp(2.4rem,4.6vw,3.9rem)] font-semibold leading-[1.02]">
            Alma goiana,
            <em className="font-normal italic text-ember"> sotaque belga.</em>
          </h2>
          <div className="mt-7 space-y-5 text-lg leading-relaxed text-paper-muted">
            <p>
              Nosso nome é uma homenagem a Bruxelas, e quem chega é recebido pelo{" "}
              <strong className="font-semibold text-paper-foreground">Manneken Pis</strong>, o
              menino-fonte mais famoso da Bélgica, que virou o símbolo da casa e guarda a nossa
              porta no Jardim Atlântico.
            </p>
            <p>
              Lá dentro, o sotaque é goiano: carne na brasa, jiló, pequi, torresmo crocante e aquele
              mexidão que chega borbulhando na panela de ferro. Tudo servido com cerveja trincando e
              drinks feitos na hora.
            </p>
          </div>

          <dl className="mt-10 grid grid-cols-3 divide-x divide-paper-line border-y border-paper-line py-6">
            {[
              [`${Math.floor(itemCount / 10) * 10}+`, "itens no cardápio"],
              ["2020", "acendemos a brasa"],
              ["5", "noites por semana"],
            ].map(([n, l]) => (
              <div key={l} className="px-4 first:pl-0">
                <dt className="font-display text-4xl font-semibold text-ember md:text-5xl">{n}</dt>
                <dd className="mt-1 text-sm text-paper-muted">{l}</dd>
              </div>
            ))}
          </dl>
        </div>

        <div className="reveal relative mx-auto w-full max-w-[520px]">
          <div className="arch relative aspect-[4/5] overflow-hidden shadow-paper ring-1 ring-paper-line">
            <img
              src={img.fachada}
              alt="Fachada do Bruxelas Grill com a fonte do Manneken Pis na entrada"
              className="h-full w-full object-cover object-[center_35%]"
              loading="lazy"
            />
          </div>
          <figure className="absolute -bottom-10 -left-6 w-[46%] rotate-[-4deg] bg-paper p-2.5 pb-8 shadow-paper ring-1 ring-paper-line md:-left-14">
            <img
              src={img.insta2}
              alt="Amigos reunidos à mesa no Bruxelas Grill"
              className="aspect-square w-full object-cover"
              loading="lazy"
            />
            <figcaption className="absolute inset-x-0 bottom-2 text-center font-display text-sm italic text-paper-muted">
              noite de sexta
            </figcaption>
          </figure>
        </div>
      </div>

      <div className="container-site mt-28">
        <div className="grid gap-px overflow-hidden rounded-2xl border border-paper-line bg-paper-line sm:grid-cols-2 lg:grid-cols-4">
          {pillars.map(({ icon: Icon, title, text }) => (
            <div key={title} className="reveal bg-paper p-7">
              <Icon className="size-7 text-ember" strokeWidth={1.5} />
              <h3 className="mt-5 text-xl font-semibold">{title}</h3>
              <p className="mt-2 text-[0.95rem] leading-relaxed text-paper-muted">{text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
