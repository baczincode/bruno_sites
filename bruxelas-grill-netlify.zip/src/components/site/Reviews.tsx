import { Star } from "lucide-react";

// Trechos de avaliações públicas de clientes no Google.
const reviews = [
  { text: "Comida deliciosa, cerveja gelada e uns drinks diferenciados!", who: "Cliente no Google" },
  { text: "Local maravilhoso, com comida boa, ótimo atendimento. Super recomendo!", who: "Cliente no Google" },
  { text: "Ótimo lugar, recomendo muito. Atendentes nota 10.", who: "Cliente no Google" },
];

export function Reviews() {
  return (
    <section className="section-paper pb-24 pt-4 md:pb-28">
      <div className="container-site">
        <div className="reveal flex flex-col items-center gap-3 text-center">
          <div className="flex gap-1 text-ember">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star key={i} className="size-5 fill-current" />
            ))}
          </div>
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-paper-muted">Quem vem, recomenda</p>
        </div>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {reviews.map((r) => (
            <figure key={r.text} className="reveal relative rounded-2xl bg-paper-deep p-8 ring-1 ring-paper-line">
              <span aria-hidden="true" className="absolute -top-6 left-6 font-display text-8xl leading-none text-ember/80">
                “
              </span>
              <blockquote className="font-display text-xl leading-snug md:text-2xl">{r.text}</blockquote>
              <figcaption className="mt-6 text-sm font-medium text-paper-muted">— {r.who}</figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}
