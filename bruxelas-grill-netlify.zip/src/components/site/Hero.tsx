import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowRight, Clock, MapPin, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { img } from "@/lib/images";
import { links, openStatus, site } from "@/lib/site";
import { cn } from "@/lib/utils";

export function Hero() {
  const [status, setStatus] = useState<{ open: boolean; text: string } | null>(null);

  useEffect(() => {
    const now = new Date();
    setStatus(openStatus(now.getDay(), now.getHours() * 60 + now.getMinutes()));
  }, []);

  return (
    <section id="inicio" className="relative isolate flex min-h-[100svh] items-end overflow-hidden">
      <img
        src={img.heroPicanha}
        alt="Picanha fatiada sobre tábua de madeira, com a brasa acesa ao fundo"
        className="absolute inset-0 -z-20 h-full w-full scale-105 object-cover object-[70%_center]"
        fetchPriority="high"
      />
      <div className="bg-gradient-hero absolute inset-0 -z-10" />
      <div className="grain -z-10" />

      <div className="container-site w-full pb-40 pt-32 md:pb-48">
        <div className="max-w-2xl">
          <p className="eyebrow animate-rise">{site.tagline}</p>
          <h1 className="mt-6 animate-rise text-[clamp(2.9rem,7.4vw,6.2rem)] font-semibold leading-[0.95] text-foreground [animation-delay:120ms]">
            Brasa acesa,
            <br />
            <em className="font-normal italic text-primary">cerveja gelada</em>
            <br />e mesa cheia.
          </h1>
          <p className="mt-7 max-w-lg animate-rise text-lg leading-relaxed text-foreground/80 [animation-delay:240ms]">
            Picanha na grelha, torresmo da roça, petiscos para dividir e drinks bem feitos. Um gastrobar
            de alma goiana com sotaque belga, feito para reunir amigos e família.
          </p>
          <div className="mt-10 flex animate-rise flex-wrap gap-3 [animation-delay:360ms]">
            <Button asChild variant="hero" size="xl">
              <Link to="/cardapio">
                Ver o cardápio <ArrowRight />
              </Link>
            </Button>
            <Button asChild variant="glass" size="xl">
              <a href={links.whatsapp} target="_blank" rel="noopener noreferrer">
                Reservar mesa
              </a>
            </Button>
          </div>
        </div>
      </div>

      <div className="absolute inset-x-0 bottom-0 border-t border-foreground/10 bg-coal/70 backdrop-blur-xl">
        <div className="container-site grid grid-cols-2 gap-x-6 gap-y-4 py-5 md:grid-cols-4">
          <HeroFact icon={<Clock />} label="Hoje">
            <span className="inline-flex items-center gap-2">
              <span
                className={cn(
                  "size-2 rounded-full",
                  status?.open ? "animate-ember bg-whatsapp" : "bg-primary",
                )}
              />
              {status?.text ?? "Ter a sáb · a partir das 17h"}
            </span>
          </HeroFact>
          <HeroFact icon={<MapPin />} label="Endereço">
            Av. Padre Orlando de Morais, 551
          </HeroFact>
          <HeroFact icon={<Star />} label="No Google">
            4,1 · mais de 170 avaliações
          </HeroFact>
          <HeroFact icon={<ArrowRight />} label="Delivery" className="hidden md:flex">
            <a href={links.order} target="_blank" rel="noopener noreferrer" className="underline-offset-4 hover:underline">
              Peça pelo cardápio digital
            </a>
          </HeroFact>
        </div>
      </div>
    </section>
  );
}

function HeroFact({
  icon,
  label,
  children,
  className,
}: {
  icon: React.ReactNode;
  label: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex min-w-0 items-start gap-3", className)}>
      <span className="mt-0.5 text-primary [&_svg]:size-4">{icon}</span>
      <div className="min-w-0">
        <p className="text-[0.65rem] font-semibold uppercase tracking-[0.2em] text-muted-foreground">{label}</p>
        <p className="mt-1 truncate text-sm font-medium text-foreground">{children}</p>
      </div>
    </div>
  );
}
