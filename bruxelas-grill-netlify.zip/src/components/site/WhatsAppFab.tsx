import { WhatsAppIcon } from "@/components/site/icons";
import { links } from "@/lib/site";

export function WhatsAppFab() {
  return (
    <a
      href={links.whatsapp}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Conversar pelo WhatsApp"
      className="fixed bottom-5 right-5 z-40 grid size-14 place-items-center rounded-full bg-whatsapp text-whatsapp-foreground shadow-elegant transition-transform duration-300 hover:scale-110"
    >
      <WhatsAppIcon className="size-7" />
    </a>
  );
}
