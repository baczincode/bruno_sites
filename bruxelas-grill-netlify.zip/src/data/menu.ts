// Cardápio extraído do cardápio digital oficial (VUCA Food). Preços em reais.
export type MenuItem = { name: string; price: string; desc?: string; img?: string };
export type MenuCategory = { name: string; items: MenuItem[] };

export const menu: MenuCategory[] = [
  {
    "name": "Espetinhos completos",
    "items": [
      {
        "name": "Espetinho de Frango Completo",
        "price": "39,99"
      },
      {
        "name": "Espetinho Frango com Bacon Completo",
        "price": "39,99"
      },
      {
        "name": "Espetinho Cupim Completo",
        "price": "39,99"
      },
      {
        "name": "Espetinho Coração Completo",
        "price": "39,99"
      },
      {
        "name": "Espetinho Picanha Completo",
        "price": "47,99"
      },
      {
        "name": "Espetinho Contra Filé Completo",
        "price": "41,99"
      },
      {
        "name": "Espetinho Queijo Coalho Completo",
        "price": "39,99"
      }
    ]
  },
  {
    "name": "Entradas",
    "items": [
      {
        "name": "Ceviche de Tilápia",
        "price": "59,99",
        "desc": "Cubos de filé de tilápia marinados em cítrica, mix de pimentas e pimentões, cebola roxa, tomate cereja, cubos de manga e cheiro verde. Acompanha chips de mandioca.",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/jyihhhdqb1kd1uz71mzg.jpg"
      },
      {
        "name": "Saladinha da Roça",
        "price": "45,99",
        "desc": "Mix de folhas, repolho roxo, fios de cenoura, ovo de codorna, tomate cereja, cebola roxa, queijo e cubos de manga. Servido em cestinha crocante, acompanha molho citrico da chefe.",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/g9ngxweheniuc9zlogbs.jpg"
      },
      {
        "name": "Jiló Caipira",
        "price": "39,99",
        "desc": "Lâmina de jiló marinados em cítrica, mix de pimenta, cheiro verde, cebola roxa, pimenta biquinho. Acompanha cesta de pães da casa",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/qbxlwsyr2gekoh2yrojp.jpg"
      }
    ]
  },
  {
    "name": "Petiscos",
    "items": [
      {
        "name": "Fritas A Palito 300g",
        "price": "19,99"
      },
      {
        "name": "Batata Especial 300g",
        "price": "35,99",
        "desc": "Servidas com cheddar e bacon ou muçarela e bacon."
      },
      {
        "name": "Pastelzinho de Queijo 6 Unid",
        "price": "24,99"
      },
      {
        "name": "Torresmo Caipira",
        "price": "44,99",
        "desc": "Porção de torresmo da roça, super crocante. Acompanha mandioca na manteiga de ervas e aioli de limão cravo.",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/r6kuhtkkkc1wco6mqduy.jpg"
      },
      {
        "name": "Pastelzinho de Carne com Queijo 6 Unid",
        "price": "24,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/l1rbvopukfcc5msbqvtk.jpg"
      },
      {
        "name": "Pastelzinho Frango 6 Unid",
        "price": "28,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/b4y8ppdlydlujzwvodcs.jpg"
      },
      {
        "name": "Fritas À Palito 600g",
        "price": "39,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/g8d8hn1hee3fa76l19bw.jpg"
      },
      {
        "name": "Batata Especial 600g",
        "price": "69,99",
        "desc": "Servidas com cheddar e bacon ou muçarela e bacon."
      },
      {
        "name": "Batata Ao Boi Breado 800g",
        "price": "75,99",
        "desc": "Batatas rústicas atoladas em costela bovina desfiada assada lentamente na Char Boiler, breada com delicioso mix de queijo cremoso.",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/cahxnnm2hvyzbra1z1xj.jpg"
      },
      {
        "name": "Pastelzinho de Carne com Queijo 10 Unidd",
        "price": "39,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/qrcl1d6sefxkf7wmzgbz.jpg"
      },
      {
        "name": "Pastelzinho de Queijo 10 Unidd",
        "price": "39,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/uju5fbqxfokj1q14yfza.jpg"
      },
      {
        "name": "Pastelzinho de Frango 10 Unid",
        "price": "44,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/ijsf0qfjuutr5cguszby.jpg"
      },
      {
        "name": "Tilápia Empanada 500g",
        "price": "89,99",
        "desc": "Filé de tilápia empanado na farinha panko. Acompanha aioli de limão.",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/y9wsitv7mvorkro1nzlm.jpg"
      },
      {
        "name": "Torresmo Laminado",
        "price": "39,99",
        "desc": "Tirinhas de barriga crocantes, sem gordura, servido no aramado. Acompanha mandioca cozida, molho aioli e limão",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/nwjzuktqguzzy1vkmmii.jpg"
      }
    ]
  },
  {
    "name": "Petiscos da casa",
    "items": [
      {
        "name": "Frango Passarinho C/ Arroz",
        "price": "79,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/a8c9e0b76eb8534ff7c94b2ddd382f42619a2d27.jpg"
      },
      {
        "name": "Cercado da Roça C/ Arroz",
        "price": "99,99",
        "desc": "Costelinha suina assada e caramelizada no molho barbecue da casa. Servida com cubos de mandioca frita. Acompanha molho barbecue a parte e finalizado com farofinha de bacon",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/posf9gl5z3baxihuh19s.jpg"
      },
      {
        "name": "Cercado da Roça Petisco",
        "price": "84,99",
        "desc": "Costelinha suína caramelizada no molho barbecue. Servida com mandioca frita. Acompanha farofinha de bacon."
      },
      {
        "name": "Fígado com Jiló C/ Torrada",
        "price": "65,99",
        "desc": "Irresistível tirinhas de fígado acebolado com jiló, finalizado com pimenta biquinho. Acompanha torradas.",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/8858366abddf9ab68f86228673ad58f881caf95f.jpg"
      },
      {
        "name": "Fígado com Jiló C/ Arroz",
        "price": "75,99",
        "desc": "Irresistível tirinhas de fígado acebolado com jiló, finalizado com pimenta biquinho. Acompanha arroz.",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/ueettjv2xitp7x3vvjil.jpg"
      },
      {
        "name": "Frango Passarinho Petisco",
        "price": "69,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/x6skm39fdbuenbwbty4u.jpg"
      }
    ]
  },
  {
    "name": "Massas",
    "items": [
      {
        "name": "Linguine com Camarões 1 Pessoa",
        "price": "69,99",
        "desc": "Massa linguine ao molho branco com camarões grelhados e ervilhas frescas.",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/tz1tc7pwgmjlixd4ydpb.jpg"
      },
      {
        "name": "Linguine com Camarões 2 Pessoas",
        "price": "139,99",
        "desc": "Massa linguine ao molho branco com camarões grelhados e ervilhas frescas."
      },
      {
        "name": "Penne 4 Queijos 1 Pessoa",
        "price": "29,99"
      },
      {
        "name": "Penne 4 Queijos 2 Pessoas",
        "price": "59,99"
      },
      {
        "name": "Penne 4 Queijos 4 Pessoas",
        "price": "119,99"
      },
      {
        "name": "Penne Bolonhesa 1 Pessoa",
        "price": "29,99"
      },
      {
        "name": "Penne Bolonhesa 2 Pessoas",
        "price": "59,99"
      },
      {
        "name": "Penne Bolonhesa 4 Pessoas",
        "price": "119,99"
      }
    ]
  },
  {
    "name": "Pratos individuais",
    "items": [
      {
        "name": "Picanha Grelhada",
        "price": "79,99",
        "desc": "Picanha, arroz ao alho, batata frita e salada do dia."
      },
      {
        "name": "Tilápia Grelhada",
        "price": "69,99",
        "desc": "Filé de tilápia, arroz com raspa de limão, batata frita e salada do dia."
      },
      {
        "name": "Frango Grelhado",
        "price": "45,99",
        "desc": "Filé de frango, arroz branco, batata frita e salada do dia."
      },
      {
        "name": "Cupim Grelhado",
        "price": "64,99",
        "desc": "Cupim, arroz branco, batata frita e salada do dia."
      },
      {
        "name": "Omelete do Peão",
        "price": "31,99",
        "desc": "ovos, bacon e queijo"
      },
      {
        "name": "Omelete do Patrão",
        "price": "61,99",
        "desc": "Ovos, frango caipira desfiado, queijo meia cura, milho verde, jiló e tomatinho cereja.",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/cmq8k6bojj7tpk3rhhy5.jpg"
      }
    ]
  },
  {
    "name": "Mexidões",
    "items": [
      {
        "name": "Mexidão Vila Rica 4P",
        "price": "189,99",
        "desc": "Arroz cremoso com carne de sol, linguiça, queijo coalho, lombo de porco, banana da terra e jiló. Finalizado com queijo gratinado.",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/dciopsrpz6qxrj4ulnvq.jpg"
      },
      {
        "name": "Mexidão Vila Rica 2P",
        "price": "109,99",
        "desc": "Arroz cremoso com carne de sol, linguiça, queijo coalho, lombo de porco, banana da terra e jiló. Finalizado com queijo gratinado."
      },
      {
        "name": "Mexidão do Cerrado 2 Pessoas",
        "price": "109,99",
        "desc": "Arroz cremoso com cubos de frango, lasca de pequi e milho. Finalizado com queijo gratinado."
      },
      {
        "name": "Mexidão do Cerrado 4 Pessoas",
        "price": "189,99",
        "desc": "Arroz cremoso com cubos de frango, lasca de pequi e milho. Finalizado com queijo gratinado."
      }
    ]
  },
  {
    "name": "Para os amados filhotes",
    "items": [
      {
        "name": "Franguinho Kids",
        "price": "33,99",
        "desc": "Tirinhas de frango grelhados, arroz branco, feijãozinho de caldo, fritas e saladinha."
      },
      {
        "name": "Filezinho Kids",
        "price": "35,99",
        "desc": "Tirinhas de filé grelhadas, arroz branco, feijãozinho de caldo, fritas e saladinha.",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/aljvk0m2hkde6vjgplpc.jpg"
      }
    ]
  },
  {
    "name": "Espetinhos",
    "items": [
      {
        "name": "Espetinho de Frango",
        "price": "19,99",
        "desc": "Acompanha mandioca",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/qgzvnlp80e86uxyrted3.jpg"
      },
      {
        "name": "Espetinho Frango com Bacon",
        "price": "19,99",
        "desc": "Acompanha mandioca",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/dmt0zelrz7avyhe2urq8.jpg"
      },
      {
        "name": "Espetinho Cupim",
        "price": "19,99",
        "desc": "Acompanha mandioca"
      },
      {
        "name": "Espetinho Coração",
        "price": "19,99",
        "desc": "Acompanha mandioca"
      },
      {
        "name": "Espetinho Contra Filé",
        "price": "20,99",
        "desc": "Acompanha mandioca"
      },
      {
        "name": "Espetinho Picanha",
        "price": "26,99",
        "desc": "Acompanha mandioca"
      },
      {
        "name": "Espetinho Queijo Coalho",
        "price": "19,99",
        "desc": "Acompanha mandioca"
      }
    ]
  },
  {
    "name": "Porções",
    "items": [
      {
        "name": "Arroz Branco Médio",
        "price": "9,45",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/sdteeauwvpewgf9hkwrv.jpg"
      },
      {
        "name": "Feijão Tropeiro Médio",
        "price": "14,45",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/uw2scfxkyggdlyqyr8xw.jpg"
      },
      {
        "name": "Mandioca Médio",
        "price": "11,45",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/kbio5jciqhjbwx935z6i.jpg"
      },
      {
        "name": "Vinagrete Médio",
        "price": "10,45",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/rhpvfxczehuzmmnvrpt2.jpg"
      },
      {
        "name": "Porção de Farofa de Ovo",
        "price": "10,00"
      },
      {
        "name": "Vinagrete Pp",
        "price": "5,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/yrsyugumzbgg6o3o3vb7.jpg"
      },
      {
        "name": "Arroz Branco",
        "price": "18,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/edlsjf6zy0envwm0re1q.jpg"
      },
      {
        "name": "Feijão Tropeiro",
        "price": "28,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/xudtmfhvxo68koeh6mkv.jpg"
      },
      {
        "name": "Vinagrete",
        "price": "20,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/xiorcdt4pmelfzfdfoes.jpg"
      },
      {
        "name": "Mandioca",
        "price": "22,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/cpohbktdmlrjwinyjlym.jpg"
      },
      {
        "name": "Arroz com Alho",
        "price": "22,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/v3yzny43yayyzjo7hjiy.jpg"
      },
      {
        "name": "Banana A Milanesa",
        "price": "17,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/eellraccpxqfhvuqywt5.jpg"
      },
      {
        "name": "Porção de Macarrão",
        "price": "22,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/h1u0yw0tpzkrknczdf1j.jpg"
      },
      {
        "name": "Porção de Torrada",
        "price": "5,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/b6mlo9ekendqbes3w1ez.jpg"
      }
    ]
  },
  {
    "name": "Águas",
    "items": [
      {
        "name": "Água sem Gás",
        "price": "5,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/xzinnvt57hnpy0v45wy2.jpg"
      },
      {
        "name": "Água com Gás",
        "price": "7,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/kq7sekty1gkel8gd0lkj.jpg"
      },
      {
        "name": "Água Tônica",
        "price": "7,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/xjejexscjqzitzseza31.png"
      },
      {
        "name": "Água de Coco",
        "price": "8,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/zpj8gx4s9rbnmafpnosl.webp"
      }
    ]
  },
  {
    "name": "Sucos",
    "items": [
      {
        "name": "Creme de Maracujá",
        "price": "22,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/bzekw3qc0qggehxz1q4h.jpg"
      },
      {
        "name": "Suco de Abacaxi",
        "price": "12,90"
      },
      {
        "name": "Suco de Caju",
        "price": "12,90"
      },
      {
        "name": "Creme de Morango",
        "price": "19,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/iu0twx3ginzuiawr3tul.jpg"
      },
      {
        "name": "Suco de Maracujá",
        "price": "12,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/ezgucufluzsqqneyr35v.jpg"
      },
      {
        "name": "Suco de Morango",
        "price": "12,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/p8gfecv2pww4tebprwqo.jpg"
      },
      {
        "name": "Suco de Laranja",
        "price": "12,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/iqs870ka7kmben4azng1.jpg"
      },
      {
        "name": "Suco de Limão",
        "price": "12,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/hywmdsirjcwcywxi2de3.jpg"
      },
      {
        "name": "Suco de Uva",
        "price": "12,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/iuwytolhkuiloc21ehsm.jpg"
      },
      {
        "name": "Suco de Acerola",
        "price": "12,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/c7roe5kb8ypbbpbvwflz.jpg"
      },
      {
        "name": "Caldo de Limão",
        "price": "3,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/xoyq1nonqpoeizwlfihm.jpg"
      },
      {
        "name": "Suco de Laranja com Acerola",
        "price": "15,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/taxkuodqanse2qeppugh.jpg"
      },
      {
        "name": "Suco de Morango com Maracujá",
        "price": "15,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/bbd6nhrukeygrn0agivp.jpg"
      },
      {
        "name": "Suco de Abacaxi com Hortelã",
        "price": "15,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/xc1sfdn0bq5bskyplyus.jpg"
      },
      {
        "name": "Suco de Laranja com Morango",
        "price": "15,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/qvbugjz5y7eqiu29rdln.jpg"
      }
    ]
  },
  {
    "name": "Refrigerantes",
    "items": [
      {
        "name": "Coca Cola",
        "price": "8,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/yufacblcm0qvyqp23gbh.jpg"
      },
      {
        "name": "Coca Cola Zero",
        "price": "8,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/inefoeh8ejof6zav5vxx.jpg"
      },
      {
        "name": "Guaraná",
        "price": "8,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/e3uyxpgrhdmv0t5lwmtn.jpg"
      },
      {
        "name": "Guaraná Zero",
        "price": "8,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/iff8ysnqkuwqdoy2630x.jpg"
      },
      {
        "name": "Sprite",
        "price": "8,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/q46koem3g79nmspfslz0.jpg"
      },
      {
        "name": "H20",
        "price": "8,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/lxnhuvslr8eyxnilq7rn.jpg"
      }
    ]
  },
  {
    "name": "Energéticos",
    "items": [
      {
        "name": "Red Bull Original",
        "price": "16,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/zntaltltxlsopnbrkrva.jpg"
      }
    ]
  },
  {
    "name": "Drinks sem álcool",
    "items": [
      {
        "name": "Soda Italiana Maçã Verde",
        "price": "19,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/vrrnje3y14rgvpm7tp9f.jpg"
      },
      {
        "name": "Soda Italiana Morango",
        "price": "19,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/hmymxbzdcjq3bzciglwb.jpg"
      },
      {
        "name": "Soda Italiana Maracujá",
        "price": "19,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/dtkxnomwdtod9xxqxspo.jpg"
      },
      {
        "name": "Virgin Mojito",
        "price": "19,99",
        "desc": "Suco de limão, xarope de açúcar, hortelã e água com gás."
      }
    ]
  },
  {
    "name": "Drinks com álcool",
    "items": [
      {
        "name": "Aperol Spritz",
        "price": "24,99",
        "desc": "Aperol, espumante e laranja",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/qaa2wnsschzebikummox.jpg"
      },
      {
        "name": "Gin Tônica Tradicional",
        "price": "24,99",
        "desc": "Gin, limão siciliano e tônica"
      },
      {
        "name": "Gin Tônica Morango",
        "price": "24,99",
        "desc": "Gin, morango, xarope de morango e tônica"
      },
      {
        "name": "Gin Tropical",
        "price": "24,99",
        "desc": "Gin, laranja fruta, e energético tropical"
      },
      {
        "name": "Moscow Gin",
        "price": "24,99",
        "desc": "fruta à escolha:Morango, limão siciliano, maracujá ou tangerina."
      },
      {
        "name": "Gin Tônica",
        "price": "24,99",
        "desc": "Gin, tônica e espuma de gengibre."
      },
      {
        "name": "Margarita Cuervo",
        "price": "24,99",
        "desc": "Tequila prata, limão, cointreau e curaçau blue."
      },
      {
        "name": "Mojito Tradicional",
        "price": "24,99",
        "desc": "Hortelã, rum, limão, xarope de açúcar e água com gás."
      },
      {
        "name": "Moscow Mule",
        "price": "24,99",
        "desc": "Vodka, caldo de limão, xarope de açúcar e espuma de gengibre"
      },
      {
        "name": "Pina Colada",
        "price": "24,99",
        "desc": "Rum, abacaxi, coco ralado",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/ti1b0mxeswu7ooaz9f7r.jpg"
      },
      {
        "name": "Campari Orange",
        "price": "24,99",
        "desc": "Campari, caldo de laranja"
      },
      {
        "name": "Caipirinha Limão",
        "price": "24,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/wmpmz1pouwjbljmevyfz.jpg"
      },
      {
        "name": "Caipirinha Maracujá",
        "price": "24,99"
      },
      {
        "name": "Caipirinha Morango",
        "price": "24,99"
      },
      {
        "name": "Caipiroska Limão",
        "price": "24,99"
      },
      {
        "name": "Caipiroska Maracujá",
        "price": "24,99"
      },
      {
        "name": "Caipiroska Morango",
        "price": "24,99"
      },
      {
        "name": "Negroni",
        "price": "24,99",
        "desc": "Gin, vermute, campari"
      }
    ]
  },
  {
    "name": "Cervejas",
    "items": [
      {
        "name": "Amstel 600ml",
        "price": "14,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/bismxdke2kfmny99h5oq.jpg"
      },
      {
        "name": "Cozumel",
        "price": "15,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/ni3n9d6wsa0ki6rv9fqa.jpg"
      },
      {
        "name": "Heineken Puro Malte 600ml",
        "price": "19,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/lehldwtfvyticff5jpz0.jpg"
      },
      {
        "name": "Long Neck Heineken Puro Malte",
        "price": "12,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/nrbfxer8im5ptdjjrikw.webp"
      },
      {
        "name": "Long Neck Heineken 0",
        "price": "12,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/pfb4awnrtc6olzwhnnsa.webp"
      },
      {
        "name": "Preparo de Cozumel",
        "price": "7,90",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/oglsdxiekksrcesgtkcz.jpg"
      }
    ]
  },
  {
    "name": "Doses",
    "items": [
      {
        "name": "Dose 51",
        "price": "5,00"
      },
      {
        "name": "Dose Cachaça Ypioca",
        "price": "18,00"
      },
      {
        "name": "Dose Licor 43",
        "price": "30,00"
      },
      {
        "name": "Dose Campari",
        "price": "20,00"
      },
      {
        "name": "Dose Johnnie Walker Red Label",
        "price": "23,00"
      },
      {
        "name": "Dose Old Parr 12",
        "price": "25,00"
      },
      {
        "name": "Dose Buchanan's 12",
        "price": "25,00"
      },
      {
        "name": "Dose Absolut",
        "price": "25,00"
      },
      {
        "name": "Dose Smirnoff",
        "price": "15,00"
      },
      {
        "name": "Dose Balena",
        "price": "23,00"
      },
      {
        "name": "Dose Paratudo",
        "price": "18,00"
      },
      {
        "name": "Dose Gin Tanqueray",
        "price": "36,00"
      },
      {
        "name": "Licor de Milho",
        "price": "15,00"
      },
      {
        "name": "Licor Doce de Leite",
        "price": "15,00"
      },
      {
        "name": "Licor Tuti Fruit",
        "price": "15,00"
      },
      {
        "name": "Licor Creme de Avelã",
        "price": "15,00"
      },
      {
        "name": "Licor Blue Ice",
        "price": "15,00"
      },
      {
        "name": "Licor 73",
        "price": "18,00"
      },
      {
        "name": "Dose Jack Daniel's",
        "price": "25,00"
      },
      {
        "name": "Dose Tequila Loka",
        "price": "18,00"
      }
    ]
  },
  {
    "name": "Garrafas",
    "items": [
      {
        "name": "Cachaça Ypioca",
        "price": "130,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/kzpvcok87mhohezrjbkt.jpg"
      },
      {
        "name": "Licor 43",
        "price": "290,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/twiavpaqbwbma5ykesvf.jpg"
      },
      {
        "name": "Campari",
        "price": "150,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/qxva7pq8gkwzyeuan3kb.jpg"
      },
      {
        "name": "Johnnie Walker Black Label",
        "price": "400,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/isml4z4bdxplpmci3bkd.jpg"
      },
      {
        "name": "Johnnie Walker Red Label",
        "price": "290,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/jgq1bjur5rx2sg3vc7qu.jpg"
      },
      {
        "name": "Johnnie Walker Gold Label",
        "price": "530,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/orbha8bhmwasajvfpmyq.jpg"
      },
      {
        "name": "Old Parr 12",
        "price": "290,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/laab3l9pxcghqpjhyas8.jpg"
      },
      {
        "name": "Buchanan's 12",
        "price": "290,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/lqrhay3qxfbp9rftlojr.jpg"
      },
      {
        "name": "Chivas 12",
        "price": "390,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/uuggwijizp9k6gd4cbb6.jpg"
      },
      {
        "name": "Absolut",
        "price": "200,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/hh4fupqy3gznalvp3iwn.jpg"
      },
      {
        "name": "Smirnoff",
        "price": "150,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/rwd40blge7exnvuuiqrg.jpg"
      },
      {
        "name": "Jose Cuervo Silver",
        "price": "290,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/fo3rk2nhmjrsszf0pk41.jpg"
      },
      {
        "name": "Jose Cuervo Gold",
        "price": "290,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/nevnu9mtl9e05vgycopc.jpg"
      },
      {
        "name": "Balena",
        "price": "200,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/bcljsg5ikoxsaiffxpvo.jpg"
      },
      {
        "name": "Paratudo",
        "price": "130,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/q59queekls4pcn6crkgi.jpg"
      },
      {
        "name": "Gin Tanqueray",
        "price": "400,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/fvnsg6ais7ht4hi7rtdb.jpg"
      }
    ]
  },
  {
    "name": "Carta de vinhos",
    "items": [
      {
        "name": "Taça Metropolitano",
        "price": "30,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/5ff739bb09f0388f3416cd681cba311a11323a62.jpg"
      },
      {
        "name": "Intimista",
        "price": "79,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/70642306c086fe92a26bd90e8e69f29ddfb597e9.jpg"
      },
      {
        "name": "Olaria",
        "price": "79,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/fb940c9d267a6d961c16030c7bf2ecbb973e8365.jpg"
      },
      {
        "name": "Chac Chac",
        "price": "89,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/ef1d8e9bbc3a1b33fbc732b128ffdebfbd7d4b54.jpg"
      },
      {
        "name": "La Linda",
        "price": "109,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/4bd6506284ffdc7fa5a82ba09ebfbdf3660d97ae.jpg"
      },
      {
        "name": "Esteban Martin Rose",
        "price": "79,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/36bbdfb937d1bb9b353a622793aeaad9439b3658.jpg"
      },
      {
        "name": "Cabernet Sauvignon",
        "price": "79,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/a9a020fae777a23d3bf0f1f0a88f11326b56f016.jpg"
      },
      {
        "name": "Sauvignon Blanc",
        "price": "79,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/2216b167ad67beb4d2b9f71048ac916cc1835af2.jpg"
      },
      {
        "name": "Carmenere",
        "price": "79,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/b635e7a3cc1c97bcec1156c1e6c64dc7cf4ff39b.jpg"
      },
      {
        "name": "Alecrim",
        "price": "69,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/38cb380cb77277a707a0185d2a536d33cb03a56d.jpg"
      },
      {
        "name": "Taça Alecrim",
        "price": "30,00",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/9f9e52f10069b0848e9003326f5b8780456a2d46.jpg"
      },
      {
        "name": "Casal Garcia",
        "price": "49,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/23642be0bb2ff0cca08fb95d5b6344768b619be1.jpg"
      },
      {
        "name": "Metropolitano",
        "price": "69,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/3482a3f4182182c93d4154b4f6f623a7befc24c6.jpg"
      }
    ]
  },
  {
    "name": "Espumantes",
    "items": [
      {
        "name": "Casa Perini / Branco - Brut",
        "price": "109,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/cf7858581469250635dc7019e7ae992e4ada91cc.jpg"
      },
      {
        "name": "Undurraga Brut",
        "price": "89,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/387bb5f8ba242a5075895899e7520124c8959119.jpg"
      },
      {
        "name": "Undurraga Sweet",
        "price": "89,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/5d345e6a3eb641771aad0d8c3eb04755daa6af34.jpg"
      },
      {
        "name": "Casa Perini / Brut - Rose",
        "price": "109,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/fa7a53e5d83fb7c73497dd72d2fd2c5219a55bf6.jpg"
      },
      {
        "name": "Casa Perini Aquarela",
        "price": "109,99",
        "img": "https://cdn.vucasolution.com.br/upload/w_480,h_480,c_fill/https://gryyplgyeyqb.compat.objectstorage.sa-saopaulo-1.oraclecloud.com/vuca-cdn/bruxelasgrill/arqs/produtos/f71fb68555f2f46b330227298ec4896c3fadeae9.jpg"
      }
    ]
  }
];
