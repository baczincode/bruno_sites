// Dados oficiais do Bruxelas Grill usados em todo o site.
export const site = {
  name: "Bruxelas Grill",
  tagline: "Gastrobar · Jardim Atlântico · Goiânia",
  since: 2020,
  phone: "(62) 99360-4845",
  phoneDigits: "5562993604845",
  address: "Avenida Padre Orlando de Morais, 551",
  neighborhood: "Jardim Atlântico",
  city: "Goiânia – GO",
  cep: "74843-590",
  instagramHandle: "@bruxelasgrill",
};

const mapsQuery = `${site.address}, ${site.neighborhood}, Goiânia - GO, ${site.cep}`;

export const links = {
  menu: "https://www.vucafood.com.br/bruxelasgrill/2631/cardapio-digital",
  order: "https://www.vucafood.com.br/bruxelasgrill/2631",
  instagram: "https://www.instagram.com/bruxelasgrill/",
  whatsapp: `https://wa.me/${site.phoneDigits}?text=${encodeURIComponent("Olá, Bruxelas Grill! Gostaria de fazer uma reserva.")}`,
  tel: `tel:+${site.phoneDigits}`,
  maps: `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(mapsQuery)}`,
  mapsEmbed: `https://www.google.com/maps?q=${encodeURIComponent(mapsQuery)}&z=16&output=embed`,
};

export type DeliveryPlatform = {
  id: "ifood" | "99food";
  label: string;
  phrase: string;
  /** Link oficial da loja. Vazio = a faixa não aparece no site. */
  url: string;
};

// Coloque aqui o link oficial de cada plataforma. Sem link, a faixa fica oculta.
export const delivery: DeliveryPlatform[] = [
  {
    id: "ifood",
    label: "iFood",
    phrase: "Deu fome? Estamos no iFood!",
    url: "https://www.ifood.com.br/busca?q=Bruxelas%20Grill",
  },
  {
    id: "99food",
    label: "99 Food",
    phrase: "...Também estamos no 99 Food!",
    url: "",
  },
];

export function activeDelivery(list: DeliveryPlatform[] = delivery) {
  return list.filter((p) => p.url.trim() !== "");
}

// Horários em minutos desde 00:00 (null = fechado). 24*60 = meia-noite. Índice 0 = domingo.

export const hours: { day: string; label: string; open: number | null; close: number | null }[] = [
  { day: "Domingo", label: "Fechado", open: null, close: null },
  { day: "Segunda", label: "Fechado", open: null, close: null },
  { day: "Terça", label: "18h às 23h", open: 18 * 60, close: 23 * 60 },
  { day: "Quarta", label: "18h às 23h", open: 18 * 60, close: 23 * 60 },
  { day: "Quinta", label: "18h às 23h", open: 18 * 60, close: 23 * 60 },
  { day: "Sexta", label: "17h30 à meia-noite", open: 17 * 60 + 30, close: 24 * 60 },
  { day: "Sábado", label: "17h à meia-noite", open: 17 * 60, close: 24 * 60 },
];

/** Status de funcionamento para um horário local (dia 0 = domingo). */
export function openStatus(weekday: number, minutes: number) {
  const today = hours[weekday % 7]!;
  if (today.open !== null && today.close !== null && minutes >= today.open && minutes < today.close) {
    return { open: true, text: `Aberto agora · até ${today.close === 24 * 60 ? "meia-noite" : `${today.close / 60}h`}` };
  }
  if (today.open !== null && minutes < today.open) {
    return { open: false, text: `Abrimos hoje às ${today.label.split(" ")[0]}` };
  }
  for (let i = 1; i <= 7; i++) {
    const d = hours[(weekday + i) % 7]!;
    if (d.open !== null) {
      return { open: false, text: `Abrimos ${i === 1 ? "amanhã" : d.day.toLowerCase()} às ${d.label.split(" ")[0]}` };
    }
  }
  return { open: false, text: "Consulte nossos horários" };
}
