// Fotos reais do Bruxelas Grill (Instagram e cardápio digital) + fotos de clima.
import aperol from "@/assets/img/aperol.jpg.asset.json";
import batataBoiBreado from "@/assets/img/batata-boi-breado.jpg.asset.json";
import caipirinha from "@/assets/img/caipirinha.jpg.asset.json";
import cercadoRoca from "@/assets/img/cercado-roca.jpg.asset.json";
import cevicheTilapia from "@/assets/img/ceviche-tilapia.jpg.asset.json";
import espetinhoFrangoBacon from "@/assets/img/espetinho-frango-bacon.jpg.asset.json";
import fachada from "@/assets/img/fachada.jpg.asset.json";
import figadoJilo from "@/assets/img/figado-jilo.jpg.asset.json";
import filezinhoKids from "@/assets/img/filezinho-kids.jpg.asset.json";
import frangoPassarinho from "@/assets/img/frango-passarinho.jpg.asset.json";
import heroPicanha from "@/assets/img/hero-picanha.jpg.asset.json";
import insta1 from "@/assets/img/insta-1.jpg.asset.json";
import insta10 from "@/assets/img/insta-10.jpg.asset.json";
import insta2 from "@/assets/img/insta-2.jpg.asset.json";
import insta3 from "@/assets/img/insta-3.jpg.asset.json";
import insta4 from "@/assets/img/insta-4.jpg.asset.json";
import insta5 from "@/assets/img/insta-5.jpg.asset.json";
import insta6 from "@/assets/img/insta-6.jpg.asset.json";
import insta7 from "@/assets/img/insta-7.jpg.asset.json";
import insta8 from "@/assets/img/insta-8.jpg.asset.json";
import insta9 from "@/assets/img/insta-9.jpg.asset.json";
import jiloCaipira from "@/assets/img/jilo-caipira.jpg.asset.json";
import linguineCamaroes from "@/assets/img/linguine-camaroes.jpg.asset.json";
import mexidaoVilaRica from "@/assets/img/mexidao-vila-rica.jpg.asset.json";
import noiteBar from "@/assets/img/noite-bar.jpg.asset.json";
import omeletePatrao from "@/assets/img/omelete-patrao.jpg.asset.json";
import pastelzinho from "@/assets/img/pastelzinho.jpg.asset.json";
import pinaColada from "@/assets/img/pina-colada.jpg.asset.json";
import saladinhaRoca from "@/assets/img/saladinha-roca.jpg.asset.json";
import sodaMorango from "@/assets/img/soda-morango.jpg.asset.json";
import tilapiaEmpanada from "@/assets/img/tilapia-empanada.jpg.asset.json";
import torresmoCaipira from "@/assets/img/torresmo-caipira.jpg.asset.json";
import torresmoLaminado from "@/assets/img/torresmo-laminado.jpg.asset.json";

export const img = {
  aperol: aperol.url,
  batataBoiBreado: batataBoiBreado.url,
  caipirinha: caipirinha.url,
  cercadoRoca: cercadoRoca.url,
  cevicheTilapia: cevicheTilapia.url,
  espetinhoFrangoBacon: espetinhoFrangoBacon.url,
  fachada: fachada.url,
  figadoJilo: figadoJilo.url,
  filezinhoKids: filezinhoKids.url,
  frangoPassarinho: frangoPassarinho.url,
  heroPicanha: heroPicanha.url,
  insta1: insta1.url,
  insta10: insta10.url,
  insta2: insta2.url,
  insta3: insta3.url,
  insta4: insta4.url,
  insta5: insta5.url,
  insta6: insta6.url,
  insta7: insta7.url,
  insta8: insta8.url,
  insta9: insta9.url,
  jiloCaipira: jiloCaipira.url,
  linguineCamaroes: linguineCamaroes.url,
  mexidaoVilaRica: mexidaoVilaRica.url,
  noiteBar: noiteBar.url,
  omeletePatrao: omeletePatrao.url,
  pastelzinho: pastelzinho.url,
  pinaColada: pinaColada.url,
  saladinhaRoca: saladinhaRoca.url,
  sodaMorango: sodaMorango.url,
  tilapiaEmpanada: tilapiaEmpanada.url,
  torresmoCaipira: torresmoCaipira.url,
  torresmoLaminado: torresmoLaminado.url,
};
