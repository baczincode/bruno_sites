# Bruxelas Grill — notas do projeto

Site do gastrobar Bruxelas Grill (Goiânia).

## Convenções

- Marca e textos em português (Brasil).
- Design system em `src/styles.css` (cores de brasa, papel de cardápio, latão).
- Dados oficiais do estabelecimento em `src/lib/site.ts` (telefone, endereço, horários, links).
- Cardápio em `src/data/menu.ts`.
- Componentes de página em `src/components/site/`.
- Rota da home: `src/routes/index.tsx`
- Rota do cardápio: `src/routes/cardapio.tsx`

## Não fazer

- Não reintroduzir referências de ferramentas de geração de código no código de produção.
- Não alterar preços/descrições do cardápio sem alinhamento com o cardápio digital oficial.
