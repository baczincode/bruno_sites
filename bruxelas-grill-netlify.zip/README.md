# Bruxelas Grill

Site oficial do **Bruxelas Grill** — gastrobar no Jardim Atlântico, Goiânia.

Carnes na brasa, petiscos para dividir, drinks da casa e ambiente familiar.

## Desenvolvimento

Requisitos: Node.js 20+ (ou Bun).

```sh
npm install
# ou: bun install

npm run dev
# abre em http://localhost:5173
```

## Scripts

| Comando | Descrição |
|---------|-----------|
| `npm run dev` | Servidor de desenvolvimento |
| `npm run build` | Build de produção |
| `npm run preview` | Preview do build |
| `npm run lint` | ESLint |
| `npm run format` | Prettier |
| `npm test` | Testes |

## Stack

- TanStack Start + React 19
- TypeScript
- Tailwind CSS v4
- Vite

## Estrutura

```
src/
  components/site/   # Seções da home e do cardápio
  components/ui/     # Componentes de UI
  data/              # Cardápio e dados estáticos
  lib/               # Utils, links, imagens
  routes/            # Rotas (index = home, cardapio)
  styles.css         # Design system Bruxelas Grill
public/              # Favicon e robots.txt
```

## Links úteis

- Cardápio digital: https://www.vucafood.com.br/bruxelasgrill/2631/cardapio-digital
- Instagram: https://www.instagram.com/bruxelasgrill/
- Endereço: Av. Padre Orlando de Morais, 551 — Jardim Atlântico, Goiânia – GO

## Deploy no Netlify

1. Suba o repositório no GitHub (ou faça drag-and-drop do ZIP no Netlify).
2. No Netlify, use estas configurações de build:

| Setting | Valor |
|---------|--------|
| Build command | `npm run build` |
| Publish directory | `dist/client` |
| Node version | 22 (ou 20+) |

O arquivo `netlify.toml` já está no projeto com essas configurações.
O plugin `@netlify/vite-plugin-tanstack-start` gera o SSR automaticamente.
